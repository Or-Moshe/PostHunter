# PostHunter

## Frontend
Browser Extension for Flagging Antisemitic Anti-Israeli Posts and Tweets, Prompting Users to Report Them.
For posts and tweets supporting Israel, users will receive a suggestion for sharing and liking.

## Backend
Server for storing the reported posts, updating the other users with a new report on a post.
